# Geektext\Wishlist\serializers.py
from rest_framework import serializers
from .models import Book, Wishlist, ShoppingCart

class WishlistSerializer(serializers.ModelSerializer):
    class Meta:
        model = Wishlist
        fields = ['id', 'name']

class BookSerializer(serializers.ModelSerializer):
    wishlists = WishlistSerializer(many=True)

    class Meta:
        model = Book
        fields = ['id', 'title', 'author', 'wishlists']

class ShoppingCartSerializer(serializers.ModelSerializer):
    books = BookSerializer(many=True)

    class Meta:
        model = ShoppingCart
        fields = '__all__'

class ListBooksSerializer(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields = ['id', 'title', 'author']