from django.urls import path
from .views import BookListCreateView, BookDetailView, WishlistListCreateView, WishlistDetailView, WishlistCreateView, AddBookToWishlistView, RemoveBookFromWishlistView, ListBooksInWishlistView

urlpatterns = [
    path('api/books/', BookListCreateView.as_view(), name='book-list'),
    path('api/books/<int:pk>/', BookDetailView.as_view(), name='book-detail'),
    path('api/wishlists/', WishlistListCreateView.as_view(), name='wishlist-list'),
    path('api/wishlists/<int:pk>/', WishlistDetailView.as_view(), name='wishlist-detail'),
    path('api/wishlist/create/', WishlistCreateView.as_view(), name='wishlist-create'),
    path('create/', WishlistCreateView.as_view(), name='create-wishlist'),
    path('api/wishlist/create/', WishlistCreateView.as_view(), name='wishlist-create'),
    path('api/wishlist/add_book/', AddBookToWishlistView.as_view(), name='add-book-to-wishlist'),
    path('api/wishlist/remove_book/', RemoveBookFromWishlistView.as_view(), name='remove-book-from-wishlist'),
    path('api/wishlist/list_books/', ListBooksInWishlistView.as_view(), name='list-books-in-wishlist'),

]
