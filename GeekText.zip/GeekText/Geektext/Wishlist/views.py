# Geektext\Wishlist\views.py
from rest_framework import generics, status
from rest_framework.authentication import SessionAuthentication
from rest_framework.generics import CreateAPIView, DestroyAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_409_CONFLICT
from django.contrib.auth.models import User
from rest_framework.views import APIView

from .models import Book, Wishlist, ShoppingCart
from .serializers import BookSerializer, WishlistSerializer, ShoppingCartSerializer, ListBooksSerializer


class BookListCreateView(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class BookDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class WishlistListCreateView(generics.ListCreateAPIView):
    queryset = Wishlist.objects.all()
    serializer_class = WishlistSerializer

class WishlistDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Wishlist.objects.all()
    serializer_class = WishlistSerializer

class WishlistCreateView(generics.CreateAPIView):
    serializer_class = WishlistSerializer

    def create(self, request, *args, **kwargs):
        user_id = request.data.get('user_id')
        wishlist_name = request.data.get('wishlist_name')


        try:
            user = User.objects.get(pk=user_id)
            wishlist, created = Wishlist.objects.get_or_create(user=user, name=wishlist_name)

            if created:
                return Response(status=HTTP_201_CREATED)
            else:
                return Response({"message": "Wishlist with the same name already exists for this user."})
        except User.DoesNotExist:
            return Response({"message": "User with the provided user_id does not exist."})


class AddBookToWishlistView(CreateAPIView):
    serializer_class = BookSerializer

    def create(self, request, *args, **kwargs):
        book_id = request.data.get('book_id')
        wishlist_id = request.data.get('wishlist_id')

        try:
            book = Book.objects.get(pk=book_id)
            wishlist = Wishlist.objects.get(pk=wishlist_id)

            # Check if the book is not already in the wishlist
            if wishlist in book.wishlists.all():
                return Response({"message": "Book is already in the wishlist."}, status=status.HTTP_409_CONFLICT)

            # Add the wishlist to the book's wishlists
            book.wishlists.add(wishlist)
            return Response(status=status.HTTP_201_CREATED)

        except Book.DoesNotExist:
            return Response({"message": "Book with the provided book_id does not exist."}, status=status.HTTP_404_NOT_FOUND)

        except Wishlist.DoesNotExist:
            return Response({"message": "Wishlist with the provided wishlist_id does not exist."}, status=status.HTTP_404_NOT_FOUND)

class RemoveBookFromWishlistView(APIView):
    def delete(self, request, *args, **kwargs):
        book_id = request.data.get('book_id')
        wishlist_id = request.data.get('wishlist_id')

        try:
            book = Book.objects.get(pk=book_id)
            wishlist = Wishlist.objects.get(pk=wishlist_id)

            # Check if the book is in the wishlist
            if book in wishlist.books.all():
                wishlist.books.remove(book)

                # Add the book to the user's shopping cart
                shopping_cart, created = ShoppingCart.objects.get_or_create(user=request.user)
                shopping_cart.books.add(book)

                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response(status=status.HTTP_404_NOT_FOUND)
        except Book.DoesNotExist:
            return Response({"message": "Book with the provided book_id does not exist."}, status=status.HTTP_404_NOT_FOUND)
        except Wishlist.DoesNotExist:
            return Response({"message": "Wishlist with the provided wishlist_id does not exist."}, status=status.HTTP_404_NOT_FOUND)


class ListBooksInWishlistView(generics.ListAPIView):
    serializer_class = ListBooksSerializer

    def get_queryset(self):
        wishlist_id = self.request.query_params.get('wishlist_id')
        try:
            wishlist = Wishlist.objects.get(pk=wishlist_id)
            return wishlist.books.all()
        except Wishlist.DoesNotExist:
            return []