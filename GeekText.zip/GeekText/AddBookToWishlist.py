import requests

def add_book_to_wishlist():
    url = 'http://127.0.0.1:8000/api/wishlist/add_book/'
    data = {
        #we will now add books to wishlist id number4
        'book_id': 22,
        'wishlist_id': 4
    }

    response = requests.post(url, json=data)

    if response.status_code == 201:
        print("Book added to wishlist successfully!")
    elif response.status_code == 400:
        print("Bad request. Check your data.")
    elif response.status_code == 409:
        print("Book is already in the wishlist.")
    else:
        print(f"Failed to add book to wishlist. Status code: {response.status_code}")

if __name__ == "__main__":
    add_book_to_wishlist()
