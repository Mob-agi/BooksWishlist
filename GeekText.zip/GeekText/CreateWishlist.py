import requests

def create_wishlist():
    url = 'http://127.0.0.1:8000/api/wishlist/create/'
    data = {
        'user_id': 1,
        'wishlist_name': 'Memoir'
    }

    response = requests.post(url, json=data)

    if response.status_code == 201:
        print("Wishlist created successfully!")
    elif response.status_code == 400:
        print("Bad request. Check your data.")
    elif response.status_code == 409:
        print("Wishlist with the same name already exists for this user.")
    else:
        print(f"Failed to create wishlist. Status code: {response.status_code}")

if __name__ == "__main__":
    create_wishlist()
