import requests
#finally we are seeing the books on our wishlist.
def list_books_in_wishlist():
    wishlist_id = 4  # Replace with the valid wishlist_id
    url = f'http://127.0.0.1:8000/api/wishlist/list_books/?wishlist_id={wishlist_id}'

    response = requests.get(url)

    if response.status_code == 200:
        books = response.json()
        if isinstance(books, list) and len(books) > 0:
            print("Books in the wishlist:")
            for book in books:
                title = book.get('title', 'Unknown Title')
                print(f"- {title}")
        else:
            print("No books found in the wishlist.")
    elif response.status_code == 404:
        print("Wishlist not found. Check your wishlist_id.")
    else:
        print(f"Failed to retrieve books in the wishlist. Status code: {response.status_code}")

if __name__ == "__main__":
    list_books_in_wishlist()
