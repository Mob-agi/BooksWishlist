import requests
from requests.auth import HTTPBasicAuth

#Removing book from wishlist by giving its id.
def remove_book_from_wishlist():
    url = 'http://127.0.0.1:8000/api/wishlist/remove_book/'
    data = {
        'book_id': 10 ,  # Replace with the valid book_id
        'wishlist_id': 4,  # Replace with the valid wishlist_id
    }

    # Assuming you have a valid username and password for authentication
    username = 'user2'
    password = 'password2'

    # Make the DELETE request with authentication headers
    response = requests.delete(url, json=data, auth=HTTPBasicAuth(username, password))

    if response.status_code == 204:
        print("Book removed from wishlist successfully!")
    elif response.status_code == 404:
        print("Book or wishlist not found.")
    else:
        print(f"Failed to remove book from wishlist. Status code: {response.status_code}")


if __name__ == "__main__":
    remove_book_from_wishlist()
